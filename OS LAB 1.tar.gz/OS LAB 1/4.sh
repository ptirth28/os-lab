
echo "Enter Source: "
read SOURCE

printf "\n"

echo "Enter Destination: "
read DEST

printf "\n"

mv $SOURCE $DEST
