OUT="$(ls *.c)"

gcc ${OUT}
